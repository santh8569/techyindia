require('../../modules/es6.object.define-property');
var $Object = require('../../modules/_core').Object;
module.exports = function defineProperty(it, key, desc) {
    return $Object.defineProperty(it, key, desc);
};


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/fn/object/define-property.js
// module id = 46
// module chunks = 0