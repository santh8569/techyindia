require('../../modules/es6.object.assign');
module.exports = require('../../modules/_core').Object.assign;


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/fn/object/assign.js
// module id = 44
// module chunks = 0