require('../modules/web.dom.iterable');
require('../modules/es6.string.iterator');
module.exports = require('../modules/core.get-iterator');


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/fn/get-iterator.js
// module id = 43
// module chunks = 0