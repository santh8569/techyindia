module.exports = function() { /* empty */ };


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_add-to-unscopables.js
// module id = 48
// module chunks = 0