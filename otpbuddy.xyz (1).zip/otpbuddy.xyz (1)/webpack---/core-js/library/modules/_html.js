module.exports = require('./_global').document && document.documentElement;


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_html.js
// module id = 52
// module chunks = 0