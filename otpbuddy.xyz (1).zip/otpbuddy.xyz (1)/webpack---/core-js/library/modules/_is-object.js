module.exports = function(it) {
    return typeof it === 'object' ? it !== null : typeof it === 'function';
};


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_is-object.js
// module id = 18
// module chunks = 0