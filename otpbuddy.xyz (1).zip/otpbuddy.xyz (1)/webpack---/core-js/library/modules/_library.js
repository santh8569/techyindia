module.exports = true;


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_library.js
// module id = 56
// module chunks = 0