module.exports = function(done, value) {
    return {
        value: value,
        done: !!done
    };
};


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_iter-step.js
// module id = 55
// module chunks = 0