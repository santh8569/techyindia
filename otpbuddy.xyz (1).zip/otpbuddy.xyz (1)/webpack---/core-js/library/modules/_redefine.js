module.exports = require('./_hide');


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_redefine.js
// module id = 63
// module chunks = 0