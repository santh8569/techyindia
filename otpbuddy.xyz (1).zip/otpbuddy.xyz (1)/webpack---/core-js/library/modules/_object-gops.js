exports.f = Object.getOwnPropertySymbols;


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_object-gops.js
// module id = 59
// module chunks = 0