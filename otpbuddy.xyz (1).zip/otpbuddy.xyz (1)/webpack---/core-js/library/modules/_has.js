var hasOwnProperty = {}.hasOwnProperty;
module.exports = function(it, key) {
    return hasOwnProperty.call(it, key);
};


//////////////////
// WEBPACK FOOTER
// ./~/core-js/library/modules/_has.js
// module id = 10
// module chunks = 0