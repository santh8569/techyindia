module.exports = {
    "default": require("core-js/library/fn/get-iterator"),
    __esModule: true
};


//////////////////
// WEBPACK FOOTER
// ./~/babel-runtime/core-js/get-iterator.js
// module id = 15
// module chunks = 0