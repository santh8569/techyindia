module.exports = {
    "default": require("core-js/library/fn/object/define-property"),
    __esModule: true
};


//////////////////
// WEBPACK FOOTER
// ./~/babel-runtime/core-js/object/define-property.js
// module id = 39
// module chunks = 0