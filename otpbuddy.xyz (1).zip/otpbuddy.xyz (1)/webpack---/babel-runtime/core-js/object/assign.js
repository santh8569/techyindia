module.exports = {
    "default": require("core-js/library/fn/object/assign"),
    __esModule: true
};


//////////////////
// WEBPACK FOOTER
// ./~/babel-runtime/core-js/object/assign.js
// module id = 38
// module chunks = 0