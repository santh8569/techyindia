module.exports = {
    "default": require("core-js/library/fn/object/create"),
    __esModule: true
};


//////////////////
// WEBPACK FOOTER
// ./~/babel-runtime/core-js/object/create.js
// module id = 37
// module chunks = 0